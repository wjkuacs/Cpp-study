#include "point.h"

            //设置X
                void Point::setX(double x)
                {
                    m_X = x;
                }
            //获取X
                double Point::getX()
                {
                    return m_X;
                }
                //设置Y
                void Point::setY(double y)
                {
                    m_Y = y;
                }
            //获取Y
                double Point::getY()
                {
                    return m_Y;
                }